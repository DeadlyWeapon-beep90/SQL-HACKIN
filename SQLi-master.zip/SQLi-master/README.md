<h1 align="center">SQLi

</h1>
<p align="center">An open-source SQL injection Scanner.</p><br>

#### By Changing the name, You won't be a script developer...

## Note:

- The script requires working network connection to work.
- This script is only for educational purposes.
- **Developer is not responsible for the misuse of SQLi.**
<br>

## Features:

- Find Vulnerable Sites Using Google Dorks.
- Irrelevant Results Will Be Automatically Canceled Which Saves Your Time.
- Vulnerable Sites Can Be Saved In A Text File.
- Automatic VPN Detection.
- Useful For Mass Defacement(If You Want To Join Cyber War).
- Useful For Bug Bounty.
- Easy to use.

#use it as u like and modify as much u can 

